How to run code:

In command terminal: make run Value=(any positive value)

Example: make run Value=6

**Warning**
Value=(any positive value) does not include spaces
